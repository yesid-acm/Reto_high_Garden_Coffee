# =============================================================================
# HIGH GARDEN COFFEE — CHATBOT ANALÍTICO CON IA GENERATIVA
# =============================================================================
# PROPÓSITO:
#   Chatbot que permite a cualquier ejecutivo de High Garden Coffee hacer
#   preguntas en lenguaje natural sobre los resultados del EDA y los 3 modelos
#   (estadístico, ML, pronóstico), sin necesidad de abrir un notebook.
#
# ARQUITECTURA — RAG MANUAL (sin vector store):
#   Los 4 archivos parquet (EDA + 3 modelos) son pequeños (55-1650 filas) y
#   caben completos en el contexto del LLM. No se necesita un vector store
#   (Pinecone, ChromaDB) ni recuperación semántica — sería sobre-ingeniería
#   para este volumen de datos.
#
#   Archivos parquet  →  Contexto estructurado (datos + hallazgos)  →
#   →  Claude API  →  Respuesta en lenguaje natural
#
# CONTEXTO DE DOS NIVELES (clave del diseño):
#   1. HALLAZGOS REDACTADOS: los párrafos de "Conclusiones" que ya escribimos
#      en el EDA y en los 3 scripts. Esto evita que el LLM reinterprete los
#      datos desde cero y pueda inventar conclusiones distintas a las nuestras.
#   2. TABLAS DE DATOS: para preguntas específicas de cifras puntuales
#      (ej. "¿cuál es el CAGR de Perú?") que no están en los hallazgos.
#
# LIBRERÍAS:
#   - anthropic  : SDK oficial de Anthropic para llamar a Claude
#   - streamlit  : interfaz web del chatbot
#   - pandas     : lectura de los parquet con los resultados de los modelos
#
# EJECUCIÓN:
#   pip install anthropic streamlit pandas pyarrow
#   export ANTHROPIC_API_KEY="tu_api_key"
#   streamlit run app_ia_generativa.py
# =============================================================================

import os
import numpy as np
import pandas as pd
import streamlit as st
from anthropic import Anthropic

# -----------------------------------------------------------------------------
# CONFIGURACIÓN DE LA PÁGINA
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="High Garden Coffee — Asistente Analítico",
    page_icon="☕",
    layout="wide"
)

MODELO_LLM = "claude-sonnet-4-6"  # modelo actual de Claude para uso en producción

# -----------------------------------------------------------------------------
# BLOQUE 1 — CARGA DE CONTEXTO (datos + hallazgos redactados)
# -----------------------------------------------------------------------------

@st.cache_data
def cargar_datos():
    """
    Carga los 4 archivos parquet generados por el EDA y los 3 modelos.
    Se cachea con @st.cache_data para no releer en cada interacción del chat.
    """
    df_long = pd.read_parquet('coffee_procesado_long.parquet') \
              if os.path.exists('coffee_procesado_long.parquet') \
              else pd.read_parquet('coffee_db.parquet').melt(
                  id_vars=['Country', 'Coffee type'],
                  value_vars=[c for c in pd.read_parquet('coffee_db.parquet').columns if '/' in c],
                  var_name='Temporada', value_name='Consumo'
              )

    df_raw      = pd.read_parquet('coffee_db.parquet')
    df_ranking  = pd.read_parquet('ranking_mercados.parquet')
    df_segment  = pd.read_parquet('segmentacion_paises.parquet')
    df_forecast = pd.read_parquet('pronosticos_2021_2025.parquet')

    return df_raw, df_ranking, df_segment, df_forecast


def construir_tablas_resumen(df_raw, df_ranking, df_segment, df_forecast):
    """
    Construye tablas de datos compactas en texto plano para el contexto del LLM.
    Estas tablas permiten responder preguntas específicas de cifras puntuales
    que no están cubiertas por los hallazgos redactados (nivel 2 del contexto).
    """
    COLS_AÑOS = [c for c in df_raw.columns if '/' in c]

    # Tabla 1: resumen por país (consumo total, tipo, CAGR)
    tabla_paises = df_raw[['Country', 'Coffee type', 'Total_domestic_consumption']].copy()
    tabla_paises['Total_domestic_consumption'] = (
        tabla_paises['Total_domestic_consumption'] / 1e6
    ).round(1)
    tabla_paises.columns = ['Pais', 'Tipo_cafe', 'Consumo_total_millones']
    tabla_paises = tabla_paises.sort_values('Consumo_total_millones', ascending=False)
    texto_tabla_paises = tabla_paises.to_string(index=False)

    # Tabla 2: ranking de tendencia (β1) por país
    tabla_ranking = df_ranking[['Pais', 'β1_tendencia', 'R²', 'Categoría']].copy()
    tabla_ranking['β1_tendencia'] = tabla_ranking['β1_tendencia'].round(0)
    tabla_ranking['R²'] = tabla_ranking['R²'].round(3)
    tabla_ranking = tabla_ranking.sort_values('β1_tendencia', ascending=False)
    texto_tabla_ranking = tabla_ranking.to_string(index=False)

    # Tabla 3: segmentación de clustering
    tabla_segment = df_segment[['Country', 'CAGR', 'Cluster', 'Etiqueta']].copy()
    tabla_segment['CAGR'] = (tabla_segment['CAGR'] * 100).round(2)
    tabla_segment.columns = ['Pais', 'CAGR_pct', 'Cluster', 'Etiqueta_segmento']
    texto_tabla_segment = tabla_segment.to_string(index=False)

    # Tabla 4: pronósticos (resumen compacto: año final disponible en el archivo)
    tabla_forecast = df_forecast[df_forecast['Año'] == df_forecast['Año'].max()].copy()
    tabla_forecast = tabla_forecast[['Pais', 'Segmento', 'Año', 'Forecast', 'MAPE', 'AICc', 'BIC']].copy()
    tabla_forecast['Forecast'] = (tabla_forecast['Forecast'] / 1e6).round(2)
    tabla_forecast['MAPE'] = tabla_forecast['MAPE'].round(2)
    tabla_forecast['AICc'] = tabla_forecast['AICc'].round(1)
    tabla_forecast['BIC'] = tabla_forecast['BIC'].round(1)
    tabla_forecast.columns = ['Pais', 'Segmento_CAGR', 'Año', 'Pronostico_millones', 'MAPE_pct', 'AICc', 'BIC']
    texto_tabla_forecast = tabla_forecast.to_string(index=False)

    return texto_tabla_paises, texto_tabla_ranking, texto_tabla_segment, texto_tabla_forecast


# -----------------------------------------------------------------------------
# HALLAZGOS REDACTADOS — nivel 1 del contexto
# -----------------------------------------------------------------------------
# Estos son los mismos párrafos de "Conclusiones" escritos en el EDA y en los
# 3 scripts de modelos. Se inyectan tal cual para que el LLM responda con
# NUESTRA interpretación validada, no una que improvise desde los números crudos.

HALLAZGOS_EDA = """
HALLAZGOS DEL ANÁLISIS EXPLORATORIO (EDA):

1. ESCALA DEL MERCADO
   - Consumo acumulado global (1990-2020): ~61 mil millones de unidades
   - Crecimiento total del período: +156% entre 1990 y 2019
   - Tendencia sostenida al alza con R² > 0.95 (ajuste lineal del agregado global)

2. CONCENTRACIÓN DEL MERCADO
   - Los 3 principales países (Brasil, Indonesia, Etiopía) concentran
     aproximadamente el 54% del consumo global acumulado
   - Brasil es el mercado dominante por amplio margen (27.8 mil millones
     de unidades acumuladas, ~10x el segundo lugar)

3. TIPOS DE CAFÉ
   - Cuatro tipos en la base: Arabica, Robusta, Arabica/Robusta, Robusta/Arabica
   - Arabica/Robusta es el tipo con mayor participación en consumo total (53.5%)
   - Existen diferencias estadísticamente significativas entre tipos de café:
     ANOVA (F-test) y Kruskal-Wallis (no paramétrico) confirman p=0.013 < 0.05
   - Nota estadística: los datos NO cumplen normalidad (Shapiro-Wilk falla en
     los 4 grupos), por lo que Kruskal-Wallis es la prueba que respalda
     formalmente la conclusión, con el ANOVA como apoyo adicional
   - Homogeneidad de varianzas (Levene) SÍ se cumple (p=0.095)

4. MERCADOS DE ALTO CRECIMIENTO (CAGR > 5%)
   Tanzania, Viet Nam, Thailand, Côte d'Ivoire y Nicaragua lideran el
   crecimiento porcentual anual — oportunidad de expansión comercial

5. RESTRICCIONES ESTADÍSTICAS DEL ANÁLISIS
   - N=55 países limita la complejidad de modelos supervisados
   - Brasil, Indonesia y Viet Nam son outliers estructurales por volumen
     (no por error de datos) y se tratan de forma diferenciada
"""

HALLAZGOS_MODELO_ESTADISTICO = """
HALLAZGOS DEL MODELO ESTADÍSTICO (Efectos Fijos):

1. TENDENCIA GLOBAL
   - El consumo global muestra tendencia positiva significativa
     (β1 = +1,302,538 unidades/año, p < 0.0001)
   - R² = 0.913 → el modelo explica bien la varianza histórica

2. AUTOCORRELACIÓN — LIMITACIÓN IMPORTANTE
   - Durbin-Watson ≈ 0.08, muy por debajo de 1.5 → autocorrelación positiva
     severa en los residuos
   - Esto significa que el modelo de regresión OLS NO es válido como
     PREDICTOR del futuro — solo sirve como DESCRIPTOR de la tendencia
     histórica. Por eso el pronóstico real se hace con Holt-Winters,
     un modelo diseñado específicamente para series de tiempo

3. RANKING DE MERCADOS POR TENDENCIA (β1 = pendiente de crecimiento)
   - 33 países muestran mercado en crecimiento (β1 > 0)
   - 16 países muestran mercado en declive (β1 < 0)
   - 6 países muestran mercado estancado (β1 ≈ 0)
   - Esta clasificación es DESCRIPTIVA del pasado, no una proyección futura
"""

HALLAZGOS_MODELO_ML = """
HALLAZGOS DEL MODELO DE MACHINE LEARNING (Clustering K-Means):

1. METODOLOGÍA
   - Se usó clustering (no supervisado) en lugar de regresión/clasificación
     porque N=55 es insuficiente para un train/test split robusto
   - Features: CAGR, β1 de tendencia, consumo promedio, variabilidad,
     consumo reciente — transformadas con log (por distribución log-normal
     del consumo) y luego estandarizadas con Z-score
   - k óptimo = 2, seleccionado por Silhouette Score (0.44)

2. SEGMENTOS IDENTIFICADOS
   - Cluster "Mercado emergente/potencial": 28 países, CAGR promedio +2.9%
   - Cluster "Mercado estancado/declive": 25 países, CAGR promedio -1.0%

3. IMPLICACIÓN DE NEGOCIO
   - Priorizar expansión comercial en el cluster de mercados emergentes
   - Monitorear el cluster de mercados estancados para anticipar caídas
     de demanda y ajustar estrategia de exportación
"""

HALLAZGOS_MODELO_PRONOSTICO = """
HALLAZGOS DEL MODELO DE PRONÓSTICO (Holt-Winters):

1. METODOLOGÍA
   - Holt-Winters (suavización exponencial) reemplaza a OLS para pronosticar
     porque maneja tendencia y autocorrelación de forma nativa
   - Validación: walk-forward con origen expandible (5 folds), nunca se
     usan datos futuros para entrenar (sin data leakage temporal)
   - Métricas de información: AICc (corregido para n=30, obligatorio en
     muestras pequeñas) y BIC, además de MAE/RMSE/MAPE

2. SEGMENTACIÓN DEL PRONÓSTICO
   - Se proyectó el Top 5 de países por segmento CAGR:
     * Alto crecimiento (CAGR > 5%): Tanzania, Viet Nam, Thailand,
       Côte d'Ivoire, Nicaragua — CAGR promedio +8.1% anual
     * Potencial (CAGR 1%-5%): Indonesia, Uganda, Ethiopia, Brazil,
       Bolivia — CAGR promedio +3.9% anual
     * Bajo crecimiento (CAGR < 1%): Paraguay, Peru, Guatemala,
       Jamaica, Trinidad & Tobago — CAGR promedio +0.8% anual

3. PRONÓSTICO GLOBAL 2021-2025
   - MAPE global = 0.5% → pronóstico de muy alta calidad (umbral <10% es
     "muy bueno")
   - Crecimiento proyectado 2020→2025: +2.3%
   - Intervalo de confianza al 95% calculado sobre cada proyección

4. RECOMENDACIONES PARA HIGH GARDEN COFFEE
   - Mercados de alto crecimiento: priorizar acuerdos comerciales 2021-2025
   - Mercados de potencial: monitoreo y expansión gradual
   - Mercados de bajo crecimiento: evaluar rentabilidad vs costo operativo
"""

# -----------------------------------------------------------------------------
# BLOQUE 2 — SYSTEM PROMPT
# -----------------------------------------------------------------------------

def construir_system_prompt(tablas):
    """
    Construye el system prompt con el contexto de dos niveles:
    1. Hallazgos redactados (interpretación validada de negocio)
    2. Tablas de datos (para preguntas específicas de cifras)
    """
    tabla_paises, tabla_ranking, tabla_segment, tabla_forecast = tablas

    return f"""Eres el Asistente Analítico de High Garden Coffee, una empresa
exportadora de café de nivel internacional. Tu rol es ayudar a ejecutivos del
Área de Innovación a interpretar los resultados del análisis de consumo
doméstico de café (1990-2020) y sus proyecciones (2021-2025).

INSTRUCCIONES DE TONO Y FORMATO:
- Responde siempre en español, con tono ejecutivo y profesional
- Usa cifras concretas del contexto que tienes a continuación
- Si la pregunta es general/estratégica, apóyate en los HALLAZGOS redactados
- Si la pregunta pide un dato específico (ej. "CAGR de Perú"), consulta las
  TABLAS DE DATOS
- Si no tienes la información solicitada en este contexto, dilo claramente
  — no inventes cifras ni países que no aparezcan en los datos
- Sé conciso: prioriza respuestas claras y accionables sobre extensas

═══════════════════════════════════════════════════════════════════════
NIVEL 1 — HALLAZGOS REDACTADOS (interpretación de negocio ya validada)
═══════════════════════════════════════════════════════════════════════
{HALLAZGOS_EDA}
{HALLAZGOS_MODELO_ESTADISTICO}
{HALLAZGOS_MODELO_ML}
{HALLAZGOS_MODELO_PRONOSTICO}

═══════════════════════════════════════════════════════════════════════
NIVEL 2 — TABLAS DE DATOS (para preguntas de cifras específicas)
═══════════════════════════════════════════════════════════════════════

--- TABLA: Consumo total acumulado por país (millones de unidades) ---
{tabla_paises}

--- TABLA: Ranking de tendencia (β1) por país — modelo estadístico ---
{tabla_ranking}

--- TABLA: Segmentación de clustering por país ---
{tabla_segment}

--- TABLA: Pronóstico 2025 por país (Top 5 de cada segmento CAGR) ---
{tabla_forecast}
"""


# -----------------------------------------------------------------------------
# BLOQUE 3 — INTERFAZ STREAMLIT
# -----------------------------------------------------------------------------

def main():
    st.title("☕ High Garden Coffee — Asistente Analítico")
    st.caption(
        "Chatbot con IA generativa sobre el consumo doméstico de café (1990-2020) "
        "y sus proyecciones (2021-2025). Basado en EDA + 3 modelos analíticos."
    )

    # Cargar datos (cacheado)
    try:
        df_raw, df_ranking, df_segment, df_forecast = cargar_datos()
        tablas = construir_tablas_resumen(df_raw, df_ranking, df_segment, df_forecast)
    except FileNotFoundError as e:
        st.error(
            f"No se encontró un archivo necesario: {e}. "
            f"Asegúrate de ejecutar primero los scripts del EDA y los 3 modelos "
            f"(modelo_estadistico.py, modelo_ml.py, modelo_pronostico.py) en el "
            f"mismo directorio que esta app."
        )
        return

    system_prompt = construir_system_prompt(tablas)

    # ─── Sidebar: resumen de datos disponibles ───────────────────────────
    with st.sidebar:
        st.header("📊 Datos disponibles")
        st.metric("Países analizados", df_raw['Country'].nunique())
        st.metric("Período histórico", "1990–2020")
        st.metric("Horizonte de pronóstico", "2021–2025")
        st.metric("Tipos de café", df_raw['Coffee type'].nunique())

        st.divider()
        st.subheader("Fuentes del contexto")
        st.markdown("""
        - EDA — hallazgos y estadísticas descriptivas
        - Modelo estadístico — efectos fijos y tendencias
        - Modelo ML — segmentación K-Means
        - Modelo pronóstico — Holt-Winters 2021-2025
        """)

        st.divider()
        api_key = st.text_input(
            "Anthropic API Key",
            type="password",
            value=os.environ.get("ANTHROPIC_API_KEY", ""),
            help="Tu clave de API de Anthropic. También puedes definirla como "
                 "variable de entorno ANTHROPIC_API_KEY."
        )

        if st.button("🗑️ Limpiar conversación"):
            st.session_state.mensajes = []
            st.rerun()

    # ─── Bloque 5: preguntas sugeridas ────────────────────────────────────
    st.subheader("Preguntas sugeridas")
    col1, col2, col3, col4 = st.columns(4)
    preguntas_sugeridas = [
        "¿Cuáles son los mercados que debería priorizar para 2025?",
        "¿Qué países están en declive y deberíamos revisar su rentabilidad?",
        "¿Cuál es el pronóstico global de consumo para 2025?",
        "¿Cómo se compara Tanzania vs Viet Nam en crecimiento?",
    ]
    pregunta_click = None
    for col, pregunta in zip([col1, col2, col3, col4], preguntas_sugeridas):
        if col.button(pregunta, use_container_width=True):
            pregunta_click = pregunta

    st.divider()

    # ─── Bloque 4: lógica de conversación con historial ───────────────────
    if "mensajes" not in st.session_state:
        st.session_state.mensajes = []

    # Mostrar historial de conversación
    for msg in st.session_state.mensajes:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # Input del usuario (por texto o por botón de pregunta sugerida)
    entrada_usuario = st.chat_input("Pregúntame sobre el consumo de café, tendencias o pronósticos...")
    if pregunta_click:
        entrada_usuario = pregunta_click

    if entrada_usuario:
        if not api_key:
            st.error("Por favor ingresa tu Anthropic API Key en la barra lateral.")
            return

        # Mostrar mensaje del usuario
        st.session_state.mensajes.append({"role": "user", "content": entrada_usuario})
        with st.chat_message("user"):
            st.markdown(entrada_usuario)

        # Llamar a Claude con streaming
        with st.chat_message("assistant"):
            placeholder  = st.empty()
            texto_completo = ""

            try:
                client = Anthropic(api_key=api_key)

                # Cada pregunta lleva: system prompt + contexto + historial + nueva pregunta
                historial_api = [
                    {"role": m["role"], "content": m["content"]}
                    for m in st.session_state.mensajes
                ]

                with client.messages.stream(
                    model=MODELO_LLM,
                    max_tokens=1500,
                    system=system_prompt,
                    messages=historial_api,
                ) as stream:
                    for texto in stream.text_stream:
                        texto_completo += texto
                        placeholder.markdown(texto_completo + "▌")
                    placeholder.markdown(texto_completo)

            except Exception as e:
                texto_completo = f"⚠️ Error al conectar con la API de Claude: {e}"
                placeholder.markdown(texto_completo)

        st.session_state.mensajes.append({"role": "assistant", "content": texto_completo})


if __name__ == "__main__":
    main()
